<!-- Displays the contents of the skyrim_weapons_armor database -->

@extends('layout') {{-- take css from tables.blade.php in the views folder--}}

@section('content') {{-- i forgot where this comes from --}}
<!-- jquery library -->
		<script src="//code.jquery.com/jquery-1.11.2.min.js"></script>

		<h1>Skyrim Item Improving</h1>	

		<!-- Form for search box -->
     {{-- {!! Form::open(['url' => 'ajax/get','method'=>'GET','class'=>'navbar-form navbar-left','role'=>'search'])  !!}

        <div class="input-group custom-search-form">
             
            <input type="text" class="form-control" name="search" placeholder="Search...">
            <span class="input-group-btn">
                
                <button class="btn btn-default-sm" id="jsonsearchpleasework" type="submit"></button>
            </span>
        </div>
        
    {!! Form::close() !!} --}}

    <br>
	<form>
	Item Name: <input type='text' name='itemname' id='itemname' placeholder="Search...">
    <br>
	Smithing Level: <input type="number" name="smithlvl" id="smithlvl" value="15" min="15" max="100">

	{{-- {!! Form::label('smithlvl', 'Smithing Level:') !!}
	{!! Form::number('smithlvl', '15', ['min'=>15, 'max'=>100, 'id'=>'smithlvl']) !!} --}}

	<br>
	Relevant Smithing Perk <input type="checkbox" name="smithperk" id="smithperk">
	<br><br>
	Light Armor Level: <input type="number" name="lalvl" id="lalvl" value="15" min="15" max="100">
	<br>
	Agile Defender Perk Level (0-5): <input type="number" name="laperk" id="laperk" value="0" min="0" max="5">
	<br><br>
	Heavy Armor Level: <input type="number" name="halvl" id="halvl" value="15" min="15" max="100">
	<br>
	Juggernaut Perk Level (0-5): <input type="number" name="haperk" id="haperk" value="0" min="0" max="5">
	<br><br>
	One-Handed Level: <input type="number" name="ohlvl" id="ohlvl" value="15" min="15" max="100">
	<br>
	Armsman Perk Level (0-5): <input type="number" name="ohperk" id="ohperk" value="0" min="0" max="5">
	<br><br>
	Two-Handed Level: <input type="number" name="thlvl" id="thlvl" value="15" min="15" max="100">
	<br>
	Barbarian Perk Level (0-5): <input type="number" name="thperk" id="thperk" value="0" min="0" max="5">
	<br><br>
	<button class = "btn btn-success btn-submit">Submit</button>

	

	<!-- some test buttons -->
	<button id="get">Get data</button>
	<button id="post">Post data</button>

	<!-- <input type="button" name="calculate" id="caluclate" value="Calulate!" onclick="readpage"> -->
	
	<p id="test"></p>

	<script type="text/javascript">



    $.ajaxSetup({

        headers: {

            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

        }

    });



    $(".btn-submit").click(function(e){

        e.preventDefault();



        var name = $("input[name=itemname]").val();
        var smlvl = $("input[name=smithlvl]").val();
        
        var smp = 0;
        if ($("input[name=smithperk]:checked").length > 0)
        	smp = 1;

        var la = $("input[name=lalvl]").val();
        var lp = $("input[name=laperk").val();
        var ha = $("input[name=halvl").val();
        var hp = $("input[name=haperk").val();
        var ol = $("input[name=ohlvl]").val();
       	var op = $("input[name=ohperk]").val();
       	var tl = $("input[name=thlvl]").val();
       	var tp = $("input[name=thperk]").val();

        $.ajax({

           type:'POST',

           url:'/ajaxRequest',

           data:{name:name, smithlvl:smlvl, smithperk:smp, lalvl:la, laperk:lp, halvl:ha, haperk:hp, ohlvl:ol, ohperk:op, thlvl:tl, thperk:tp},

           success:function(data){

              readpage(data);
              //console.log(data.name);
              //console.log(data[0][0].rating);

           },error:function(){ 
        alert("error!!!!");
    }
        });



});

</script>

@stop