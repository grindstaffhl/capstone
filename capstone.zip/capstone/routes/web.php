<?php

/*
	--------------------------
	Routes for the website url
	--------------------------
*/


/*
	Routes for the PageController (MAIN pages)
*/
Route::get('/', 'PageController@home'); //home page


/*
	Routes for the ONLY SEEING the contents of each database
*/
Route::get('weapons', 'DBController@weapons'); //view weapons database

Route::get('armor', 'DBController@armor'); //view armor database

Route::get('effects', 'DBController@effects'); //view effects database

Route::get('perks', 'DBController@perks'); //view perks database

Route::get('weapons_armor', 'DBController@weapons_armor'); //view weapons_armor database

/*
	Routes for the database SEARCH bars
*/
Route::get('search/weapons', 'SearchController@weaponsSearch'); //search weapons database

Route::get('search/armor', 'SearchController@armorSearch'); //search armor database

Route::get('search/perks', 'SearchController@perkSearch'); //search perk database

Route::get('search/effects', 'SearchController@effectSearch'); //search effect database

Route::get('search/weapons_armor', 'SearchController@weaponsAndArmorSearch'); //search wepaons_armor database