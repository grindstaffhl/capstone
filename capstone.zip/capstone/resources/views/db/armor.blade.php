
<!-- Displays the contents of the skyrim_armor database -->

@extends('tables') {{-- take css from tables.blade.php in the views folder--}}

@section('content') {{-- i forgot where this comes from --}}

<!-- create an html table -->
<table> 
	<tr>
		<!-- create headings for the table -->
		<th>Name</th>
		<th>Defense</th>
		<th>Weight</th>
		<th>Price</th>
		<th>ID</th>
		<th>Type</th>
	</tr>

	<!-- use a laravel blade foreach loop to iterate through
		all entries of the skyrim_armor database -->
	@foreach($arms as $a)
		<tr>
			{{-- use the column names in the database --}}
			<td> {{ $a->name }} </td>
			<td> {{ $a->defense }} </td>
			<td> {{ $a->weight }} </td>
			<td> {{ $a->price }} </td>
			<td> {{ $a->id }} </td>
			<td> {{ $a->type }} </td>
		</tr>
	@endforeach
@stop