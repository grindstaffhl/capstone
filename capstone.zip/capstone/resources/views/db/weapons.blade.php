
<!-- Displays the contents of the skyrim_weapons database -->

@extends('tables') {{-- take css from tables.blade.php in the views folder--}}

@section('content') {{-- i forgot where this comes from --}}

<!-- create an html table -->
<table> 
	<tr>
		<!-- create headings for the table -->
		<th>Name</th>
		<th>Damage</th>
		<th>Weight</th>
		<th>Price</th>
		<th>ID</th>
		<th>Type</th>
	</tr>

	<!-- use a laravel blade foreach loop to iterate through
		all entries of the skyrim_weapons database -->
	@foreach($weapon as $w)
		<tr>
			{{-- use the column names in the database --}}
			<td> {{ $w->name }} </td>
			<td> {{ $w->damage }} </td>
			<td> {{ $w->weight }} </td>
			<td> {{ $w->price }} </td>
			<td> {{ $w->id }} </td>
			<td> {{ $w->type }} </td>
		</tr>
	@endforeach
@stop