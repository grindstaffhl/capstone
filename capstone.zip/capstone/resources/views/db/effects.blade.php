
<!-- Displays the contents of the skyrim_effects database -->

@extends('tables') {{-- take css from tables.blade.php in the views folder--}}

@section('content') {{-- i forgot where this comes from --}}

<!-- create an html table -->
<table> 
	<tr>
		<!-- create headings for the table -->
		<th>Name</th>
		<th>ID</th>
		<th>Description</th>
		<th>More Info</th>
	</tr>

	<!-- use a laravel blade foreach loop to iterate through
		all entries of the skyrim_effects database -->
	@foreach($effect as $e)
		<tr>
			{{-- use the column names in the database --}}
			<td> {{ $e->effect }} </td>
			<td> {{ $e->id }} </td>
			<td> {{ $e->description }} </td>
			<td> {{ $e->extra }} </td>
		</tr>
	@endforeach
@stop