
<!-- Displays the contents of the skyrim_perks database -->

@extends('tables') {{-- take css from tables.blade.php in the views folder--}}

@section('content') {{-- i forgot where this comes from --}}

<!-- create an html table -->
<table> 
	<tr>
		<!-- create headings for the table -->
		<th>Name</th>
		<th>Rank</th>
		<th>Description</th>
		<th>ID</th>
		<th>Skill Required</th>
		<th>Perk Required</th>
		<th>Tree</th>
	</tr>

	<!-- use a laravel blade foreach loop to iterate through
		all entries of the skyrim_perks database -->
	@foreach($perk as $p)
		<tr>
			{{-- use the column names in the database --}}
			<td> {{ $p->perk }} </td>
			<td> {{ $p->rank }} </td>
			<td> {{ $p->description }} </td>
			<td> {{ $p->id }} </td>
			<td> {{ $p->skill_req }} </td>
			<td> {{ $p->perk_req }} </td>
			<td> {{ $p->tree }} </td>
		</tr>
	@endforeach
@stop