@extends('layout')

@section('content')
    <h1> Skyrim Combat Skills Planner </h1>
@stop