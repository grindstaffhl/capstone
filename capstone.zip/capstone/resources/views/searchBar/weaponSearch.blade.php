@extends('tables') <!-- use tables.blade.php for formatting/css (looks at tables_style.css) -->

@section('content')

<div class="panel panel-default">

    <!-- Form for search box -->
    {!! Form::open(['method'=>'GET','class'=>'navbar-form navbar-left','role'=>'search'])  !!}

        <div class="input-group custom-search-form">
            {{-- text field for search box --}}
            <input type="text" class="form-control" name="search" placeholder="Search...">
            <span class="input-group-btn">
                {{-- search bar button (VERY SMALL RIGHT NOW) --}}
                <button class="btn btn-default-sm" type="submit"></button>
            </span>
        </div>
        
    {!! Form::close() !!}

    <!-- check if there is anything returned from the query -->
    @unless($weapons->isEmpty())
        <!-- create the table that will hold the weapons -->
        <table class="table table-bordered table-hover" >
            <thead>
                <th>Name</th>
                <th>Damage</th>
                <th>Weight</th>
                <th>Price</th>
                <th>ID</th>
                <th>Type</th>
            </thead>	
            <tbody>
                <!-- print out all of the weapons that adhere to the search value -->
                @foreach($weapons as $weapon)
                    <tr>
                        {{-- use the column name in the database --}}
                        <td>{{ $weapon->name }}</td>
                        <td> {{ $weapon->damage }} </td>
                        <td> {{ $weapon->weight }} </td>
                        <td> {{ $weapon->price }} </td>
                        <td> {{ $weapon->id }} </td>
                        <td> {{ $weapon->type }} </td>
                    </tr>
                @endforeach
            </tbody>
        </table> <!-- end the table -->
    @else
        {{ "Oops! We couldn't find what you're looking for:(" }}
    @endif
</div>

@stop