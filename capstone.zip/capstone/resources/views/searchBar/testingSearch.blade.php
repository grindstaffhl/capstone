@extends('tables') <!-- use tables.blade.php for formatting/css (looks at tables_style.css) -->

@section('content')

{!! Form::open(['method'=>'GET','class'=>'navbar-form navbar-left','role'=>'search'])  !!}

        <div class="input-group custom-search-form">
            {{-- text field for search box --}}
            <input type="text" class="form-control" name="search" placeholder="Search...">
            <span class="input-group-btn">
                {{-- search bar button (VERY SMALL RIGHT NOW) --}}
                <button class="btn btn-default-sm" type="submit"></button>
            </span>
        </div>
        
    {!! Form::close() !!}

@stop