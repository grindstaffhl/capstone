@extends('tables') <!-- use tables.blade.php for formatting/css (looks at tables_style.css) -->

@section('content')

<div class="panel panel-default">

    <!-- Form for search box -->
    {!! Form::open(['method'=>'GET','class'=>'navbar-form navbar-left','role'=>'search'])  !!}

        <div class="input-group custom-search-form">
            {{-- text field for search box --}}
            <input type="text" class="form-control" name="search" placeholder="Search...">
            <span class="input-group-btn">
                {{-- search bar button (VERY SMALL RIGHT NOW) --}}
                <button class="btn btn-default-sm" type="submit"></button>
            </span>
        </div>
        
    {!! Form::close() !!}

    <!-- check if there is anything returned from the query -->
    @unless($perk->isEmpty())
        <!-- create the table that will hold the items -->
        <table class="table table-bordered table-hover" >
            <thead>
                <th>Name</th>
                <th>Rank</th>
                <th>Description</th>
                <th>ID</th>
                <th>Skill Required</th>
                <th>Perk Required</th>
                <th>Tree</th>
            </thead>	
            <tbody>
                <!-- print out all of the items that adhere to the search value -->
                @foreach($perk as $p)
                    <tr>
                        {{-- use the column name in the database --}}
                        <td> {{ $p->perk }} </td>
                        <td> {{ $p->rank }} </td>
                        <td> {{ $p->description }} </td>
                        <td> {{ $p->id }} </td>
                        <td> {{ $p->skill_req }} </td>
                        <td> {{ $p->perk_req }} </td>
                        <td> {{ $p->tree }} </td>
                    </tr>
                @endforeach
            </tbody>
        </table> <!-- end the table -->
    @else
        {{ "Oops! We couldn't find what you're looking for:(" }}
    @endif
</div>

@stop