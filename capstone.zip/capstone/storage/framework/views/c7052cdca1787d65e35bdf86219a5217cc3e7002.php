<?php $__env->startSection('content'); ?>

<div class="panel panel-default">

    <!-- Form for search box -->
    <?php echo Form::open(['method'=>'GET','class'=>'navbar-form navbar-left','role'=>'search']); ?>


        <div class="input-group custom-search-form">
            <!-- text field for search box -->
            <input type="text" class="form-control" name="search" placeholder="Search...">
            <span class="input-group-btn">
                <!-- search bar button (VERY SMALL RIGHT NOW) -->
                <button class="btn btn-default-sm" type="submit"></button>
            </span>
        </div>
        
    <?php echo Form::close(); ?>


    <!-- create the table that will hold the weapons -->
    <table class="table table-bordered table-hover" >
        <thead>
            <th>Name</th>
        </thead>	
        <tbody>
            <!-- print out all of the weapons that adhere to the search value -->
            <?php $__currentLoopData = $weapons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weapon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($weapon->name); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table> <!-- end the table -->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('tables', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>