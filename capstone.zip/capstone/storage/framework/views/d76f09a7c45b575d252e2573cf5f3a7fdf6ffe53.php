 <!-- use tables.blade.php for formatting/css (looks at tables_style.css) -->

<?php $__env->startSection('content'); ?>

<div class="panel panel-default">

    <!-- Form for search box -->
    <?php echo Form::open(['method'=>'GET','class'=>'navbar-form navbar-left','role'=>'search']); ?>


        <div class="input-group custom-search-form">
            
            <input type="text" class="form-control" name="search" placeholder="Search...">
            <span class="input-group-btn">
                
                <button class="btn btn-default-sm" type="submit"></button>
            </span>
        </div>
        
    <?php echo Form::close(); ?>


    <!-- check if there is anything returned from the query -->
    <?php if (! ($perk->isEmpty())): ?>
        <!-- create the table that will hold the items -->
        <table class="table table-bordered table-hover" >
            <thead>
                <th>Name</th>
                <th>Rank</th>
                <th>Description</th>
                <th>ID</th>
                <th>Skill Required</th>
                <th>Perk Required</th>
                <th>Tree</th>
            </thead>	
            <tbody>
                <!-- print out all of the items that adhere to the search value -->
                <?php $__currentLoopData = $perk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td> <?php echo e($p->perk); ?> </td>
                        <td> <?php echo e($p->rank); ?> </td>
                        <td> <?php echo e($p->description); ?> </td>
                        <td> <?php echo e($p->id); ?> </td>
                        <td> <?php echo e($p->skill_req); ?> </td>
                        <td> <?php echo e($p->perk_req); ?> </td>
                        <td> <?php echo e($p->tree); ?> </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table> <!-- end the table -->
    <?php else: ?>
        <?php echo e("Oops! We couldn't find what you're looking for:("); ?>

    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('tables', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>