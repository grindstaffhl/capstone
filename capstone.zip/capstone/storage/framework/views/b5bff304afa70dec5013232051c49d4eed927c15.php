<!-- Displays the contents of the skyrim_weapons_armor database -->

 

<?php $__env->startSection('content'); ?> 

 <?php
 $myjson = json_encode($weparm);
 ?>

<?php echo e($myjson); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>