 <!-- use tables.blade.php for formatting/css (looks at tables_style.css) -->

<?php $__env->startSection('content'); ?>

<div class="panel panel-default">

    <!-- Form for search box -->
    <?php echo Form::open(['method'=>'GET','class'=>'navbar-form navbar-left','role'=>'search']); ?>


        <div class="input-group custom-search-form">
            
            <input type="text" class="form-control" name="search" placeholder="Search...">
            <span class="input-group-btn">
                
                <button class="btn btn-default-sm" type="submit"></button>
            </span>
        </div>
        
    <?php echo Form::close(); ?>


    <!-- check if there is anything returned from the query -->
    <?php if (! ($armor->isEmpty())): ?>
        <!-- create the table that will hold the items -->
        <table class="table table-bordered table-hover" >
            <thead>
                <th>Name</th>
                <th>Defense</th>
                <th>Weight</th>
                <th>Price</th>
                <th>ID</th>
                <th>Type</th>
            </thead>	
            <tbody>
               <!-- print out all of the items that adhere to the search value -->
                <?php $__currentLoopData = $armor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td><?php echo e($a->name); ?></td>
                        <td> <?php echo e($a->defense); ?> </td>
                        <td> <?php echo e($a->weight); ?> </td>
                        <td> <?php echo e($a->price); ?> </td>
                        <td> <?php echo e($a->id); ?> </td>
                        <td> <?php echo e($a->type); ?> </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table> <!-- end the table -->
    <?php else: ?>
        <?php echo e("Oops! We couldn't find what you're looking for:("); ?>

    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('tables', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>