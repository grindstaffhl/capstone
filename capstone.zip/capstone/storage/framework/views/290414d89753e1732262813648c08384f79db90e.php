<?php $__env->startSection('content'); ?>
<table> 
	<tr>
		<th>Name</th>
		<th>Rank</th>
		<th>Description</th>
		<th>ID</th>
		<th>Skill Required</th>
		<th>Perk Required</th>
		<th>Tree</th>
	</tr>

	<?php $__currentLoopData = $perk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td> <?php echo e($p->perk); ?> </td>
			<td> <?php echo e($p->rank); ?> </td>
			<td> <?php echo e($p->description); ?> </td>
			<td> <?php echo e($p->id); ?> </td>
			<td> <?php echo e($p->skill_req); ?> </td>
			<td> <?php echo e($p->perk_req); ?> </td>
			<td> <?php echo e($p->tree); ?> </td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tables', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>