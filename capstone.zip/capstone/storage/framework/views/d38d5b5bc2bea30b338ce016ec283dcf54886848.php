<!-- Displays the contents of the skyrim_weapons_armor database -->

 

<?php $__env->startSection('content'); ?> 

<!-- create an html table -->
<table> 
	<tr>
		<!-- create headings for the table -->
		<th>Name</th>
		<th>Defense</th>
		<th>Weight</th>
		<th>Price</th>
		<th>ID</th>
		<th>Type</th>
	</tr>

	<!-- use a laravel blade foreach loop to iterate through
		all entries of the skyrim_weapons_armor database -->
	<?php $__currentLoopData = $arms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			
			<td> <?php echo e($a->name); ?> </td>
			<td> <?php echo e($a->defense); ?> </td>
			<td> <?php echo e($a->weight); ?> </td>
			<td> <?php echo e($a->price); ?> </td>
			<td> <?php echo e($a->id); ?> </td>
			<td> <?php echo e($a->type); ?> </td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tables', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>