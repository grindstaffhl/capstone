 <!-- use tables.blade.php for formatting/css (looks at tables_style.css) -->

<?php $__env->startSection('content'); ?>

<?php echo Form::open(['method'=>'GET','class'=>'navbar-form navbar-left','role'=>'search']); ?>


        <div class="input-group custom-search-form">
            
            <input type="text" class="form-control" name="search" placeholder="Search...">
            <span class="input-group-btn">
                
                <button class="btn btn-default-sm" type="submit"></button>
            </span>
        </div>
        
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('tables', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>