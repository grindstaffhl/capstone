<?php $__env->startSection('content'); ?>
<table> 
	<tr>
		<th>Name</th>
		<th>ID</th>
		<th>Description</th>
		<th>More Info</th>
	</tr>

	<?php $__currentLoopData = $effect; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td> <?php echo e($e->effect); ?> </td>
			<td> <?php echo e($e->id); ?> </td>
			<td> <?php echo e($e->description); ?> </td>
			<td> <?php echo e($e->extra); ?> </td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tables', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>