<!DOCTYPE html>
<html lang="en">
<head>
	<title>Skyrim Combat Skills Planner</title>
	<link rel="stylesheet" type="text/css" href="/css/style.css">
</head>
<body>
	<?php echo $__env->yieldContent('content'); ?>
</body>
</html>