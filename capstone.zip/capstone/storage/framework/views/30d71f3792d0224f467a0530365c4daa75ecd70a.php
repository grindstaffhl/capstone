<!DOCTYPE html>
<html lang="en">
<head>
	<title>Skyrim Combat Skills P</title>
	<link rel="stylesheet" type="text/css" href="/css/tables_style.css">
	<meta name="csrf-token" content="{!! <?php echo csrf_token() ?>!!}"/>
</head>
<body>
	<?php echo $__env->yieldContent('content'); ?>
</body>
</html>