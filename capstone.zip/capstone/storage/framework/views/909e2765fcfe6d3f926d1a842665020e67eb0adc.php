<!-- Displays the contents of the skyrim_weapons database -->

 

<?php $__env->startSection('content'); ?> 

<!-- create an html table -->
<table> 
	<tr>
		<!-- create headings for the table -->
		<th>Name</th>
		<th>Damage</th>
		<th>Weight</th>
		<th>Price</th>
		<th>ID</th>
		<th>Type</th>
	</tr>

	<!-- use a laravel blade foreach loop to iterate through
		all entries of the skyrim_weapons database -->
	<?php $__currentLoopData = $weapon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			
			<td> <?php echo e($w->name); ?> </td>
			<td> <?php echo e($w->damage); ?> </td>
			<td> <?php echo e($w->weight); ?> </td>
			<td> <?php echo e($w->price); ?> </td>
			<td> <?php echo e($w->id); ?> </td>
			<td> <?php echo e($w->type); ?> </td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tables', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>