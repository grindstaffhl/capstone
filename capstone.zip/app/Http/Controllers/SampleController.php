<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SampleController extends Controller
{
    /**

     * Create a new controller instance.

     *

     * @return void

     */

    public function ajaxRequest()

    {

        return view('db.JSONtest');

    }

    /**

     * Create a new controller instance.

     *

     * @return void

     */

    public function ajaxRequestPost()

    {

        $name = request()->input('name');
        $smithlvl = request()->input('smithlvl');
        $smithperk = request()->input('smithperk');


        $input = request()->all();//array($name, $smlvl);

        $search = DB::table('skyrim_weapons_armor')
			->where('name', 'like', $name)
			->get();

		// $a = array_push($input, json_encode($search));

        $jsonstuff = response()->json($search);
        $js = json_decode($search);
        array_push($input, $js);
        //return gettype($js);
        return $input;
    }
}
